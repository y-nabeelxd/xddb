<?php
mysqli_report(MYSQLI_REPORT_OFF);
$c = new mysqli("127.0.0.1", "nabeel", "nabeelxd", "", 3306);
echo "Connected: " . $c->server_info . PHP_EOL;

// Test: query without database selected
$r = $c->query("CREATE TABLE test_no_db (id INT)");
echo "Query result: " . ($r === false ? "false" : "true") . PHP_EOL;
echo "Error: " . $c->error . PHP_EOL;

// Test: USE statement
$c->select_db("nabeelxd");
$r = $c->query("SELECT DATABASE()");
$row = $r->fetch_row();
echo "Selected DB: " . $row[0] . PHP_EOL;

// Test: CREATE USER
$r = $c->query("CREATE USER 'testuser'@'localhost' IDENTIFIED BY 'testpass'");
echo "Create user result: " . ($r === false ? "false" : "true") . PHP_EOL;
echo "Error: " . $c->error . PHP_EOL;

// Test: duplicate user
$r = $c->query("CREATE USER 'testuser'@'localhost' IDENTIFIED BY 'testpass2'");
echo "Duplicate create result: " . ($r === false ? "false" : "true") . PHP_EOL;
echo "Error: " . $c->error . PHP_EOL;

$c->query("DROP USER 'testuser'@'localhost'");
$c->close();
echo "Done." . PHP_EOL;
